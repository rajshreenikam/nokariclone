import { Component } from '@angular/core';
import { JobService } from 'src/app/services/job.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
})
export class RegistrationComponent {
  employerDetails: any = {
    employerId: 0,
    companyName: '',
    emailId: '',
    mobileNo: '',
    phoneNo: '',
    logoUrl: '',
    gstNo: '',
    city: '',
    state: '',
    pinCode: '',
    compnayAddress: '',
  };
  constructor(private job: JobService) {}
  register() {
    this.job.registerEmaployer(this.employerDetails).subscribe((res: any) => {
      if (res.result) {
        alert(res.meesage);
      } else {
        alert(res.message);
      }
    });
  }
}
