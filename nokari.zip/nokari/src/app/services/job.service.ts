import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class JobService {
  constructor(private http: HttpClient) {}

  registerEmaployer(obj: any) {
    return this.http.post(
      `https://freeapi.miniprojectideas.com/api/JobPortal/AddNewEmployer`,
      obj
    );
  }
}
